package max.login.dl;

public class DistBean {
  String distName;
  String distcode;
  String stateCode;
public String getDistName() {
	return distName;
}
public void setDistName(String distName) {
	this.distName = distName;
}
public String getDistcode() {
	return distcode;
}
public void setDistcode(String distcode) {
	this.distcode = distcode;
}
public String getStateCode() {
	return stateCode;
}
public void setStateCode(String stateCode) {
	this.stateCode = stateCode;
}
  
}
