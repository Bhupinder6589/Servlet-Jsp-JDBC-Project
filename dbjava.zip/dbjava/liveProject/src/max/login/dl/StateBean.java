package max.login.dl;

public class StateBean {
  String stateName;
  String stateCode;
  String stateShrtname;
public String getStateName() {
	return stateName;
}
public void setStateName(String stateName) {
	this.stateName = stateName;
}
public String getStateCode() {
	return stateCode;
}
public void setStateCode(String stateCode) {
	this.stateCode = stateCode;
}
public String getStateShrtname() {
	return stateShrtname;
}
public void setStateShrtname(String stateShrtname) {
	this.stateShrtname = stateShrtname;
}
  
}
