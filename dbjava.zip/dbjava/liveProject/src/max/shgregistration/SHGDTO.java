package max.shgregistration;

public class SHGDTO {
	private String sghCode;
	private String stateCode;
	 private String districtCode;
	 private String shgname;
	 private String account;
	 private String ifsc;
	 private String shgDate;
	public String getSghCode() {
		return sghCode;
	}
	public void setSghCode(String sghCode) {
		this.sghCode = sghCode;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getDistrictCode() {
		return districtCode;
	}
	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}
	public String getShgname() {
		return shgname;
	}
	public void setShgname(String shgname) {
		this.shgname = shgname;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getShgDate() {
		return shgDate;
	}
	public void setShgDate(String shgDate) {
		this.shgDate = shgDate;
	}
	 
	 
}
