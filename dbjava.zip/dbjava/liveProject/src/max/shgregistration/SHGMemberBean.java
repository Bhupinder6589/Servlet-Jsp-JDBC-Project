package max.shgregistration;

public class SHGMemberBean {
 private String[] cname;
 private String[] age;
 private String[] cadhar;
public String[] getCname() {
	return cname;
}
public void setCname(String[] cname) {
	this.cname = cname;
}
public String[] getAge() {
	return age;
}
public void setAge(String[] age) {
	this.age = age;
}
public String[] getCadhar() {
	return cadhar;
}
public void setCadhar(String[] cadhar) {
	this.cadhar = cadhar;
}
 
 
}
